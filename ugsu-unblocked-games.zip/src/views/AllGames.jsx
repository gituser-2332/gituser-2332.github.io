import React, { useState, useMemo } from 'react';
import { motion } from 'motion/react';
import { Search, Filter, Gamepad2, Star, Play } from 'lucide-react';
import { Link, useSearchParams } from 'react-router-dom';
import { GAMES, CATEGORIES } from '../data/games';

function GameCard({ game }) {
  return (
    <motion.div
      layout
      initial={{ opacity: 0, scale: 0.95 }}
      animate={{ opacity: 1, scale: 1 }}
      whileHover={{ y: -8 }}
      className="group relative"
    >
      <Link to={`/game/${game.id}`}>
        <div className="relative aspect-[4/5] rounded-3xl overflow-hidden bg-zinc-900 border border-white/5 shadow-2xl transition-all duration-500 group-hover:border-cyan-500/50">
          <img 
            src={game.thumbnail} 
            alt={game.title} 
            className="w-full h-full object-cover transition-transform duration-700 group-hover:scale-110 opacity-70 group-hover:opacity-90 grayscale-[0.5] group-hover:grayscale-0"
          />
          
          <div className="absolute inset-0 bg-gradient-to-t from-black via-black/20 to-transparent opacity-60 group-hover:opacity-80 transition-opacity" />
          
          <div className="absolute top-4 right-4 z-10">
            {game.rating && (
                <div className="flex items-center gap-1.5 px-2.5 py-1 rounded-full bg-black/60 backdrop-blur-md border border-white/10 text-yellow-500 text-[10px] font-bold">
                    <Star className="w-3 h-3 fill-current" />
                    {game.rating}
                </div>
            )}
          </div>

          <div className="absolute bottom-0 left-0 right-0 p-5 z-20 translate-y-2 group-hover:translate-y-0 transition-transform duration-500">
            <span className="inline-block px-2 py-0.5 rounded bg-cyan-500 text-black font-black text-[9px] uppercase tracking-widest mb-2 opacity-0 group-hover:opacity-100 transition-all duration-500">
              {game.category}
            </span>
            <h3 className="text-xl font-bold text-white mb-1 group-hover:text-cyan-400 transition-colors uppercase tracking-tight">{game.title}</h3>
            
            <div className="mt-4 flex items-center justify-between pt-4 border-t border-white/10 opacity-0 group-hover:opacity-100 transition-all duration-700 delay-150">
                <span className="text-[10px] font-bold text-zinc-500 font-mono tracking-widest">READY TO PLAY</span>
                <div className="w-8 h-8 rounded-full bg-white text-black flex items-center justify-center">
                    <Play className="w-4 h-4 fill-current" />
                </div>
            </div>
          </div>
        </div>
      </Link>
    </motion.div>
  );
}

export default function AllGames() {
  const [searchParams, setSearchParams] = useSearchParams();
  const [searchQuery, setSearchQuery] = useState('');
  const currentCategory = searchParams.get('category') || 'all';
  const sort = searchParams.get('sort');

  const filteredGames = useMemo(() => {
    let results = GAMES.filter(g => {
      const matchesSearch = g.title.toLowerCase().includes(searchQuery.toLowerCase());
      const matchesCategory = currentCategory === 'all' || g.category === currentCategory;
      return matchesSearch && matchesCategory;
    });

    if (sort === 'rating') {
      results = [...results].sort((a, b) => b.rating - a.rating);
    }

    return results;
  }, [currentCategory, searchQuery, sort]);

  return (
    <div className="space-y-8">
      <div className="flex flex-col md:flex-row md:items-center justify-between gap-6">
        <div>
          <h1 className="text-4xl font-black italic tracking-tighter text-white">GAME LIBRARY</h1>
          <p className="text-zinc-500 font-medium">Browse our full collection of {GAMES.length} unblocked titles</p>
        </div>

        <div className="relative w-full md:w-80">
          <Search className="absolute left-3 top-1/2 -translate-y-1/2 w-4 h-4 text-zinc-500" />
          <input 
            type="text" 
            placeholder="Search library..."
            value={searchQuery}
            onChange={(e) => setSearchQuery(e.target.value)}
            className="w-full bg-white/5 border border-white/5 rounded-xl py-2.5 pl-10 pr-4 focus:outline-none focus:ring-2 focus:ring-cyan-500/20 transition-all text-sm"
          />
        </div>
      </div>

      <div className="flex items-center gap-2 overflow-x-auto pb-2 scrollbar-none border-b border-white/5">
            {CATEGORIES.map(cat => (
                <button 
                    key={cat.id}
                    onClick={() => setSearchParams({ category: cat.id })}
                    className={`px-5 py-2 rounded-xl text-xs font-black uppercase tracking-widest transition-all border
                        ${currentCategory === cat.id 
                            ? 'bg-cyan-500 text-black border-cyan-500' 
                            : 'bg-white/5 border-white/5 text-zinc-500 hover:text-white'}`}
                >
                    {cat.name}
                </button>
            ))}
        </div>

      <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 xl:grid-cols-4 gap-8">
        {filteredGames.map((game) => (
          <GameCard key={game.id} game={game} />
        ))}
        {filteredGames.length === 0 && (
            <div className="col-span-full py-20 text-center text-zinc-500 font-medium bg-white/5 rounded-3xl border border-dashed border-white/10">
                <p className="text-lg">No games found matching your criteria.</p>
                <button onClick={() => { setSearchQuery(''); setSearchParams({ category: 'all' }); }} className="text-cyan-400 mt-2 hover:underline">Clear all filters</button>
            </div>
        )}
      </div>
    </div>
  );
}
