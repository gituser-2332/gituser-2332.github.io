import { motion } from 'motion/react';
import { Star, TrendingUp, Sparkles, Filter, ChevronRight, Play } from 'lucide-react';
import { Link, useSearchParams } from 'react-router-dom';
import { GAMES, CATEGORIES } from '../data/games';
import React, { useState, useMemo } from 'react';

function GameCard({ game }) {
  return (
    <motion.div
      layout
      initial={{ opacity: 0, scale: 0.95 }}
      animate={{ opacity: 1, scale: 1 }}
      whileHover={{ y: -8 }}
      className="group relative"
    >
      <Link to={`/game/${game.id}`}>
        <div className="relative aspect-[4/5] rounded-3xl overflow-hidden bg-zinc-900 border border-white/5 shadow-2xl transition-all duration-500 group-hover:border-cyan-500/50">
          <img 
            src={game.thumbnail} 
            alt={game.title} 
            className="w-full h-full object-cover transition-transform duration-700 group-hover:scale-110 opacity-70 group-hover:opacity-90 grayscale-[0.5] group-hover:grayscale-0"
          />
          
          <div className="absolute inset-0 bg-gradient-to-t from-black via-black/20 to-transparent opacity-60 group-hover:opacity-80 transition-opacity" />
          
          <div className="absolute top-4 right-4 z-10">
            {game.rating && (
                <div className="flex items-center gap-1.5 px-2.5 py-1 rounded-full bg-black/60 backdrop-blur-md border border-white/10 text-yellow-500 text-[10px] font-bold">
                    <Star className="w-3 h-3 fill-current" />
                    {game.rating}
                </div>
            )}
          </div>

          <div className="absolute bottom-0 left-0 right-0 p-5 z-20 translate-y-2 group-hover:translate-y-0 transition-transform duration-500">
            <span className="inline-block px-2 py-0.5 rounded bg-cyan-500 text-black font-black text-[9px] uppercase tracking-widest mb-2 opacity-0 group-hover:opacity-100 transition-all duration-500">
              {game.category}
            </span>
            <h3 className="text-xl font-bold text-white mb-1 group-hover:text-cyan-400 transition-colors uppercase tracking-tight">{game.title}</h3>
            <p className="text-xs text-zinc-400 line-clamp-1 opacity-0 group-hover:opacity-100 transition-opacity duration-500 delay-75">
                {game.description}
            </p>
            
            <div className="mt-4 flex items-center justify-between pt-4 border-t border-white/10 opacity-0 group-hover:opacity-100 transition-all duration-700 delay-150">
                <span className="text-[10px] font-bold text-zinc-500 font-mono tracking-widest">STABLE #001</span>
                <div className="w-8 h-8 rounded-full bg-white text-black flex items-center justify-center">
                    <Play className="w-4 h-4 fill-current" />
                </div>
            </div>
          </div>
        </div>
      </Link>
    </motion.div>
  );
}

export default function Home() {
  const trendingGames = GAMES.slice(0, 4);

  return (
    <div className="space-y-12">
      {/* Hero Section */}
      <section className="relative rounded-[40px] overflow-hidden min-h-[400px] flex items-center p-8 lg:p-16 border border-white/5 bg-zinc-950">
        <div className="absolute inset-0 bg-[radial-gradient(circle_at_50%_120%,rgba(34,211,238,0.15),transparent)] pointer-events-none" />
        <div className="absolute top-0 right-0 w-[500px] h-full bg-[radial-gradient(circle_at_80%_20%,rgba(168,85,247,0.1),transparent)] pointer-events-none" />
        
        <div className="relative z-10 max-w-2xl space-y-6">
            <motion.div 
                initial={{ opacity: 0, x: -20 }}
                animate={{ opacity: 1, x: 0 }}
                className="flex items-center gap-2 px-3 py-1 rounded-full bg-cyan-500/10 border border-cyan-500/20 w-fit"
            >
                <Sparkles className="w-3.5 h-3.5 text-cyan-400" />
                <span className="text-[10px] font-bold text-cyan-400 uppercase tracking-widest">UGSU Official Collection</span>
            </motion.div>
            
            <motion.h1 
                initial={{ opacity: 0, y: 20 }}
                animate={{ opacity: 1, y: 0 }}
                transition={{ delay: 0.1 }}
                className="text-5xl lg:text-7xl font-black italic tracking-tighter text-white leading-[0.9]"
            >
                LEVEL UP YOUR <br />
                <span className="text-cyan-500 underline decoration-cyan-500/20 underline-offset-8">GAMEPLAY.</span>
            </motion.h1>
            
            <motion.p 
                initial={{ opacity: 0, y: 20 }}
                animate={{ opacity: 1, y: 0 }}
                transition={{ delay: 0.2 }}
                className="text-zinc-400 text-lg max-w-lg leading-relaxed font-medium"
            >
                Access the world's best collection of unblocked gems. High performance, zero lag, and instant play anywhere.
            </motion.p>
            
            <motion.div 
                initial={{ opacity: 0 }}
                animate={{ opacity: 1 }}
                transition={{ delay: 0.3 }}
                className="flex flex-wrap gap-4 pt-4"
            >
                <Link to="/library" className="px-8 py-4 bg-white text-black font-black italic rounded-2xl hover:scale-105 transition-transform inline-block">
                    EXPLORE LIBRARY
                </Link>
                <button className="px-8 py-4 bg-zinc-900 text-white font-bold rounded-2xl border border-white/10 hover:bg-zinc-800 transition-colors">
                    OUR MISSION
                </button>
            </motion.div>
        </div>

        {/* Decorative Grid - Right side */}
        <div className="absolute right-[-100px] top-[-50px] rotate-12 opacity-20 hidden xl:grid grid-cols-3 gap-4 pointer-events-none">
            {GAMES.slice(0, 6).map(g => (
                <div key={g.id} className="w-48 h-64 rounded-2xl border border-white/10 bg-zinc-900 overflow-hidden">
                    <img src={g.thumbnail} className="w-full h-full object-cover grayscale" alt="" />
                </div>
            ))}
        </div>
      </section>

      {/* Featured Header */}
      <div className="flex flex-col md:flex-row md:items-center justify-between gap-6">
        <div className="space-y-1">
            <h2 className="text-3xl font-bold tracking-tight flex items-center gap-3">
                <TrendingUp className="text-cyan-500 w-8 h-8" />
                TRENDING NOW
            </h2>
            <p className="text-zinc-500 text-sm font-medium">Curated selection of this week's top performers</p>
        </div>

        <Link 
            to="/library"
            className="flex items-center gap-2 px-6 py-3 rounded-xl bg-white/5 border border-white/5 text-zinc-400 text-sm font-bold hover:text-white hover:bg-white/10 transition-all group"
        >
            VIEW ALL GAMES
            <ChevronRight className="w-4 h-4 group-hover:translate-x-1 transition-transform" />
        </Link>
      </div>

      {/* Game Grid (Limited) */}
      <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 xl:grid-cols-4 gap-8">
        {trendingGames.map((game) => (
          <GameCard key={game.id} game={game} />
        ))}
      </div>

      {/* Bottom Showcase */}
      <section className="grid grid-cols-1 lg:grid-cols-2 gap-8 pt-12 border-t border-white/5">
         <div className="p-8 rounded-[32px] bg-gradient-to-br from-[#101014] to-[#09090b] border border-white/5 relative overflow-hidden group">
            <div className="absolute top-0 right-0 p-8">
                <TrendingUp className="w-12 h-12 text-zinc-800 group-hover:text-cyan-500/20 transition-colors duration-500" />
            </div>
            <h3 className="text-2xl font-bold mb-4">GLOBAL LEADERBOARD</h3>
            <div className="space-y-4">
                {[1, 2, 3].map(pos => (
                    <div key={pos} className="flex items-center justify-between p-3 rounded-xl bg-black/40 border border-white/5">
                        <div className="flex items-center gap-3">
                            <span className={`w-6 text-xs font-black ${pos === 1 ? 'text-yellow-500' : 'text-zinc-500'}`}>{pos}</span>
                            <div className="w-8 h-8 rounded-lg bg-zinc-800" />
                            <span className="text-sm font-bold text-zinc-300">Player_{pos * 231}</span>
                        </div>
                        <span className="text-xs font-mono text-cyan-500">12,492 XP</span>
                    </div>
                ))}
            </div>
         </div>
         <div className="p-8 rounded-[32px] bg-cyan-500 text-black flex flex-col justify-between relative overflow-hidden group">
            <Sparkles className="absolute top-[-20px] right-[-20px] w-48 h-48 opacity-10 rotate-12 group-hover:rotate-45 transition-transform duration-1000" />
            <h3 className="text-4xl font-black italic tracking-tighter leading-none mb-8 relative z-10">
                WANT TO SUBMIT <br />YOUR GAME?
            </h3>
            <div className="flex items-center justify-between relative z-10">
                <p className="text-sm font-bold leading-tight max-w-[200px]">Join our community of unblocked developers.</p>
                <div className="w-14 h-14 rounded-full bg-black text-white flex items-center justify-center hover:scale-110 transition-transform">
                    <ChevronRight className="w-6 h-6" />
                </div>
            </div>
         </div>
      </section>
    </div>
  );
}
