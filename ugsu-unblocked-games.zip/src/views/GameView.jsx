import { motion } from 'motion/react';
import { ArrowLeft, Maximize2, ExternalLink, Star, Share2, ChevronRight } from 'lucide-react';
import { useParams, Link } from 'react-router-dom';
import { GAMES } from '../data/games';
import React, { useState } from 'react';

export default function GameView() {
  const { id } = useParams();
  const game = GAMES.find(g => g.id === id);
  const [isFullscreen, setIsFullscreen] = useState(false);

  if (!game) {
    return (
      <div className="flex flex-col items-center justify-center h-full text-zinc-500 gap-4">
        <p>Game not found</p>
        <Link to="/" className="text-cyan-400 flex items-center gap-2 hover:underline">
          <ArrowLeft className="w-4 h-4" /> Back to Dashboard
        </Link>
      </div>
    );
  }

  const toggleFullscreen = () => {
    const iframe = document.getElementById('game-iframe');
    if (iframe) {
      if (iframe.requestFullscreen) {
        iframe.requestFullscreen();
      }
    }
  };

  return (
    <motion.div 
      initial={{ opacity: 0, y: 20 }}
      animate={{ opacity: 1, y: 0 }}
      exit={{ opacity: 0, y: -20 }}
      className="space-y-6 max-w-6xl mx-auto"
    >
      <div className="flex items-center justify-between">
        <Link to="/" className="group flex items-center gap-2 text-zinc-400 hover:text-white transition-colors">
          <div className="w-8 h-8 rounded-lg bg-white/5 flex items-center justify-center group-hover:bg-white/10 transition-colors">
            <ArrowLeft className="w-4 h-4" />
          </div>
          <span className="font-medium text-sm">BACK TO DISCOVER</span>
        </Link>
        <div className="flex items-center gap-2">
            <button className="p-2.5 rounded-lg bg-white/5 text-zinc-400 hover:text-white hover:bg-white/10 transition-all">
                <Share2 className="w-4 h-4" />
            </button>
            <button onClick={toggleFullscreen} className="flex items-center gap-2 px-4 py-2 bg-cyan-500 text-black font-bold text-xs rounded-lg hover:bg-cyan-400 transition-all shadow-[0_0_20px_rgba(34,211,238,0.2)]">
                <Maximize2 className="w-4 h-4" />
                FULLSCREEN
            </button>
        </div>
      </div>

      <div className="relative aspect-video w-full rounded-2xl overflow-hidden border border-white/5 bg-zinc-900 group">
        <iframe 
          id="game-iframe"
          src={game.iframeUrl} 
          className="w-full h-full border-none"
          title={game.title}
          allowFullScreen
          allow="autoplay; fullscreen; pointer-lock"
        />
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-3 gap-8 p-1">
        <div className="lg:col-span-2 space-y-4">
            <div className="flex items-center gap-3">
                <h1 className="text-3xl font-bold tracking-tight">{game.title}</h1>
                {game.rating && (
                    <div className="flex items-center gap-1.5 px-2 py-0.5 rounded-md bg-yellow-500/10 text-yellow-500 text-xs font-bold border border-yellow-500/20">
                        <Star className="w-3.5 h-3.5 fill-current" />
                        {game.rating}
                    </div>
                )}
            </div>
            <p className="text-zinc-400 leading-relaxed text-sm lg:text-base">
                {game.description} Lorem ipsum dolor sit amet, consectetur adipiscing elit. Sed do eiusmod tempor incididunt ut labore et dolore magna aliqua. Ut enim ad minim veniam, quis nostrud exercitation ullamco laboris nisi ut aliquip ex ea commodo consequat.
            </p>
            <div className="flex flex-wrap gap-2 pt-2">
                {['Unblocked', 'Web', 'Arcade', game.category].map(tag => (
                    <span key={tag} className="px-3 py-1 rounded-full bg-white/5 border border-white/10 text-[10px] uppercase tracking-widest font-bold text-zinc-500">
                        {tag}
                    </span>
                ))}
            </div>
        </div>

        <div className="space-y-6">
            <div className="p-6 rounded-2xl bg-white/5 border border-white/5 space-y-4">
                <h3 className="font-bold text-sm uppercase tracking-widest text-zinc-500">Controls</h3>
                <div className="space-y-3">
                    <div className="flex items-center justify-between text-sm">
                        <span className="text-zinc-400">Movement</span>
                        <kbd className="px-2 py-1 bg-zinc-800 rounded text-xs font-mono">WASD</kbd>
                    </div>
                    <div className="flex items-center justify-between text-sm">
                        <span className="text-zinc-400">Action</span>
                        <kbd className="px-2 py-1 bg-zinc-800 rounded text-xs font-mono">SPACE</kbd>
                    </div>
                    <div className="flex items-center justify-between text-sm">
                        <span className="text-zinc-400">Pause</span>
                        <kbd className="px-2 py-1 bg-zinc-800 rounded text-xs font-mono">ESC</kbd>
                    </div>
                </div>
            </div>
            
            <a 
                href={game.iframeUrl} 
                target="_blank" 
                rel="noreferrer"
                className="flex items-center justify-between p-4 rounded-2xl bg-zinc-900 border border-white/5 hover:border-cyan-500/50 transition-all group"
            >
                <div className="flex items-center gap-3">
                    <div className="w-10 h-10 rounded-xl bg-white/5 flex items-center justify-center text-zinc-500 group-hover:text-cyan-400 transition-colors">
                        <ExternalLink className="w-5 h-5" />
                    </div>
                    <div>
                        <p className="text-sm font-bold">Open Original</p>
                        <p className="text-[10px] text-zinc-500 uppercase tracking-wider">Play on provider site</p>
                    </div>
                </div>
                <ChevronRight className="w-5 h-5 text-zinc-700 group-hover:text-white transition-colors" />
            </a>
        </div>
      </div>
    </motion.div>
  );
}
