export const CATEGORIES = [
  { id: 'all', name: 'All Games', icon: 'Gamepad2' },
  { id: 'action', name: 'Action', icon: 'Swords' },
  { id: 'puzzle', name: 'Puzzle', icon: 'Puzzle' },
  { id: 'classic', name: 'Classic', icon: 'History' },
  { id: 'sports', name: 'Sports', icon: 'Trophy' },
];

const BASE_GAMES = [
  { id: 'slope', title: 'Slope', category: 'action', rating: 4.8, iframeUrl: 'https://kdata1.com/2020/05/slope/' },
  { id: '1v1-lol', title: '1v1.LOL', category: 'action', rating: 4.9, iframeUrl: 'https://1v1.lol/' },
  { id: 'retro-bowl', title: 'Retro Bowl', category: 'sports', rating: 4.9, iframeUrl: 'https://game316041.konggames.com/gamefile/316041/0/RetroBowl.html' },
  { id: 'run-3', title: 'Run 3', category: 'action', rating: 4.8, iframeUrl: 'https://www.coolmathgames.com/0-run-3/play' },
  { id: 'minecraft-classic', title: 'Minecraft Classic', category: 'classic', rating: 4.9, iframeUrl: 'https://classic.minecraft.net/' },
  { id: 'moto-x3m', title: 'Moto X3M', category: 'sports', rating: 4.8, iframeUrl: 'https://moto-x3m.io/' },
  { id: 'cookie-clicker', title: 'Cookie Clicker', category: 'classic', rating: 4.7, iframeUrl: 'https://orteil.dashnet.org/cookieclicker/' },
  { id: 'geometry-dash', title: 'Geometry Dash', category: 'action', rating: 4.8, iframeUrl: 'https://geometrydash.io/' },
  { id: 'tunnel-rush', title: 'Tunnel Rush', category: 'action', rating: 4.7, iframeUrl: 'https://tunnelrush.org/' },
  { id: 'bitlife', title: 'BitLife', category: 'classic', rating: 4.6, iframeUrl: 'https://bitlifeonline.com/' },
  { id: 'paper-io-2', title: 'Paper.io 2', category: 'action', rating: 4.5, iframeUrl: 'https://paper-io.com/' },
  { id: 'basket-random', title: 'Basket Random', category: 'sports', rating: 4.8, iframeUrl: 'https://basketrandom.com/' },
  { id: 'drive-mad', title: 'Drive Mad', category: 'action', rating: 4.7, iframeUrl: 'https://drivemad.org/' },
  { id: 'smash-karts', title: 'Smash Karts', category: 'action', rating: 4.9, iframeUrl: 'https://smashkarts.io/' },
  { id: 'shell-shockers', title: 'Shell Shockers', category: 'action', rating: 4.7, iframeUrl: 'https://shellshock.io/' },
  { id: 'super-mario', title: 'Super Mario', category: 'classic', rating: 4.9, iframeUrl: 'https://supermario-game.io/' },
  { id: 'agar-io', title: 'Agar.io', category: 'action', rating: 4.4, iframeUrl: 'https://agar.io/' },
  { id: 'fireboy-watergirl-1', title: 'F&W: Forest Temple', category: 'puzzle', rating: 4.8, iframeUrl: 'https://www.fireboynwatergirl.com/fireboy-and-watergirl-1-forest-temple.html' },
  { id: 'krunker-io', title: 'Krunker.io', category: 'action', rating: 4.8, iframeUrl: 'https://krunker.io/' },
  { id: 'slither-io', title: 'Slither.io', category: 'action', rating: 4.5, iframeUrl: 'https://slither.io/' },
  { id: 'zombs-royale', title: 'Zombs Royale', category: 'action', rating: 4.7, iframeUrl: 'https://zombsroyale.io/' },
  { id: 'temple-run-2', title: 'Temple Run 2', category: 'action', rating: 4.6, iframeUrl: 'https://templerun2.io/' },
  { id: 'subway-surfers', title: 'Subway Surfers', category: 'action', rating: 4.9, iframeUrl: 'https://subwaysurfers.com/' },
  { id: 'getaway-shootout', title: 'Getaway Shootout', category: 'action', rating: 4.7, iframeUrl: 'https://getawayshootout.com/' },
  { id: 'rooftop-snipers', title: 'Rooftop Snipers', category: 'action', rating: 4.8, iframeUrl: 'https://rooftopsnipers.com/' },
  { id: 'diep-io', title: 'Diep.io', category: 'action', rating: 4.6, iframeUrl: 'https://diep.io/' },
  { id: 'hole-io', title: 'Hole.io', category: 'action', rating: 4.7, iframeUrl: 'https://hole-io.com/' },
  { id: 'crossy-road', title: 'Crossy Road', category: 'classic', rating: 4.8, iframeUrl: 'https://crossy-road.io/' },
  { id: 'bob-the-robber', title: 'Bob the Robber', category: 'puzzle', rating: 4.7, iframeUrl: 'https://bobtherobber.io/' },
  { id: 'snail-bob', title: 'Snail Bob', category: 'puzzle', rating: 4.6, iframeUrl: 'https://snailbob.io/' },
  { id: 'tomb-of-the-mask', title: 'Tomb of the Mask', category: 'action', rating: 4.8, iframeUrl: 'https://tomb-of-the-mask.io/' },
  { id: 'cut-the-rope', title: 'Cut the Rope', category: 'puzzle', rating: 4.9, iframeUrl: 'https://cuttherope.net/' },
  { id: 'pacman-classic', title: 'Pac-Man', category: 'classic', rating: 4.9, iframeUrl: 'https://www.google.com/logos/2010/pacman10-i.html' }
];

const THUMBNAILS = [
  'https://images.unsplash.com/photo-1614332287897-cdc485fa562d',
  'https://images.unsplash.com/photo-1542751371-adc38448a05e',
  'https://images.unsplash.com/photo-1550745165-9bc0b252726f',
  'https://images.unsplash.com/photo-1579373903781-fd5c0c30c4cd',
  'https://images.unsplash.com/photo-1552820728-8b83bb6b773f',
  'https://images.unsplash.com/photo-1506784881475-0e408ec284a1',
  'https://images.unsplash.com/photo-1503376780353-7e6692767b70',
  'https://images.unsplash.com/photo-1546519638-68e109498ffc',
  'https://images.unsplash.com/photo-1593113598332-cd288d649433',
  'https://images.unsplash.com/photo-1508098682722-e99c43a406b2'
];

function generateGames(count) {
  const games = [...BASE_GAMES];
  const genericTitles = ['Vex', 'Wheely', 'Adam and Eve', 'Kingdom Rush', 'Bloons', 'Stick War', 'Age of War', 'Raft Wars', 'Gun Mayhem', 'Bad Piggies', 'Among Us', 'Fall Guys', 'Roblox', 'Terraria', 'Stardew', 'Doodle Jump', 'Helix Jump', 'Stack Ball', 'Tile Busters', 'Zuma', 'Bejeweled', 'Sudoku', 'Wordle', 'Connect 4', 'Battleship', '8 Ball Pool', 'Soccer Physics', 'Wrestle Jump'];
  
  for (let i = games.length; i < count; i++) {
    const baseTitle = genericTitles[i % genericTitles.length];
    const version = Math.floor(i / genericTitles.length) + 1;
    const category = CATEGORIES[1 + (i % (CATEGORIES.length - 1))].id;
    
    games.push({
      id: `${baseTitle.toLowerCase().replace(/\s+/g, '-')}-${version}`,
      title: `${baseTitle} ${version}`,
      description: `The exciting version ${version} of the popular ${baseTitle} series. Play now for free on UGSU!`,
      thumbnail: `${THUMBNAILS[i % THUMBNAILS.length]}?auto=format&fit=crop&q=80&w=400`,
      iframeUrl: games[i % games.length].iframeUrl, // Reusing URLs as placeholders
      category: category,
      rating: parseFloat((4 + Math.random()).toFixed(1))
    });
  }
  
  // Update base games with thumbnails and descriptions if missing
  return games.map((g, i) => ({
    ...g,
    description: g.description || `${g.title} is a top-rated unblocked game on UGSU. Join millions of players online.`,
    thumbnail: g.thumbnail || `${THUMBNAILS[i % THUMBNAILS.length]}?auto=format&fit=crop&q=80&w=400`
  }));
}

export const GAMES = generateGames(500);

