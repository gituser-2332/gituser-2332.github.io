import React, { useState } from 'react';
import { BrowserRouter as Router, Routes, Route, Link, useLocation } from 'react-router-dom';
import { motion, AnimatePresence } from 'motion/react';
import { Gamepad2, Search, TrendingUp, Sparkles, Trophy, Settings } from 'lucide-react';
import { GAMES } from './data/games';
import Home from './views/Home';
import AllGames from './views/AllGames';
import GameView from './views/GameView';

function NavItem({ icon: Icon, label, to, active }) {
  return (
    <Link 
      to={to}
      className={`flex items-center gap-3 px-4 py-3 rounded-xl transition-all duration-300 group
        ${active 
          ? 'bg-cyan-500/10 text-cyan-400 border border-cyan-500/20 shadow-[0_0_15px_rgba(34,211,238,0.1)]' 
          : 'text-zinc-400 hover:text-white hover:bg-white/5'}`}
    >
      <Icon className={`w-5 h-5 transition-transform duration-300 group-hover:scale-110 ${active ? 'text-cyan-400' : 'text-zinc-500 group-hover:text-cyan-400'}`} />
      <span className="font-medium tracking-tight">{label}</span>
    </Link>
  );
}

function Layout({ children }) {
  const location = useLocation();

  return (
    <div className="min-h-screen bg-[#09090b] text-zinc-100 font-sans selection:bg-cyan-500/30">
      {/* Sidebar - Desktop */}
      <aside className="fixed left-0 top-0 bottom-0 w-64 border-r border-white/5 bg-[#09090b] hidden lg:flex flex-col z-50">
        <div className="p-6">
          <Link to="/" className="flex items-center gap-3 group">
            <div className="w-10 h-10 bg-cyan-500 rounded-lg flex items-center justify-center shadow-[0_0_20px_rgba(34,211,238,0.4)] group-hover:rotate-12 transition-transform duration-300">
              <Gamepad2 className="text-black w-6 h-6" />
            </div>
            <span className="text-xl font-bold tracking-tighter bg-gradient-to-r from-white to-zinc-500 bg-clip-text text-transparent">
              UGSU GAMES
            </span>
          </Link>
        </div>

        <nav className="flex-1 px-4 space-y-2 py-4">
          <div className="text-[10px] font-bold text-zinc-500 uppercase tracking-[0.2em] px-4 mb-2">Main Menu</div>
          <NavItem icon={TrendingUp} label="Discover" to="/" active={location.pathname === '/'} />
          <NavItem icon={Gamepad2} label="All Games" to="/library" active={location.pathname === '/library'} />
          <NavItem icon={Sparkles} label="Popular" to="/library?category=action" active={location.search.includes('action')} />
          <NavItem icon={Trophy} label="Top Rated" to="/library?sort=rating" active={location.search.includes('rating')} />
          <NavItem icon={Settings} label="Settings" to="/settings" active={location.pathname === '/settings'} />
        </nav>

        <div className="p-4 mt-auto">
          <div className="p-4 rounded-2xl bg-gradient-to-br from-zinc-900 to-black border border-white/5 relative overflow-hidden group">
            <div className="absolute inset-0 bg-cyan-500/5 opacity-0 group-hover:opacity-100 transition-opacity" />
            <p className="text-xs text-zinc-400 relative z-10">Premium Member</p>
            <p className="text-sm font-bold text-white mb-3 relative z-10">Cloud Sync Active</p>
            <button className="w-full py-2 bg-white text-black text-xs font-bold rounded-lg hover:bg-zinc-200 transition-colors relative z-10">
              VIEW STATS
            </button>
          </div>
        </div>
      </aside>

      {/* Main Content */}
      <main className="lg:ml-64 min-h-screen flex flex-col">
        {/* Header */}
        <header className="h-20 border-b border-white/5 flex items-center justify-between px-6 lg:px-10 sticky top-0 bg-[#09090b]/80 backdrop-blur-xl z-40">
          <div className="flex items-center gap-4">
             <div className="lg:hidden w-10 h-10 bg-cyan-500 rounded-lg flex items-center justify-center mr-2">
                <Gamepad2 className="text-black w-6 h-6" />
             </div>
             <div className="flex flex-col">
                <span className="text-xs text-zinc-500 font-bold uppercase tracking-widest hidden sm:block">Status</span>
                <div className="flex items-center gap-2">
                    <div className="w-2 h-2 rounded-full bg-emerald-500 shadow-[0_0_8px_rgba(16,185,129,0.5)] animate-pulse" />
                    <span className="text-sm font-bold text-white tracking-tight">System Online</span>
                </div>
             </div>
          </div>

          <div className="flex items-center gap-4">
            <div className="hidden sm:flex flex-col items-end">
              <span className="text-sm font-bold">Kushalich</span>
              <span className="text-[10px] text-cyan-400 font-mono">ID: #49201</span>
            </div>
            <div className="w-10 h-10 rounded-full border-2 border-cyan-500/20 p-0.5 bg-gradient-to-tr from-cyan-500 to-purple-500">
              <div className="w-full h-full rounded-full bg-zinc-900 overflow-hidden">
                <img 
                  src="https://api.dicebear.com/7.x/avataaars/svg?seed=Kushal" 
                  alt="Avatar" 
                  className="w-full h-full object-cover"
                />
              </div>
            </div>
          </div>
        </header>

        <div className="flex-1 p-6 lg:p-10">
          <AnimatePresence mode="wait">
             {children}
          </AnimatePresence>
        </div>

        {/* Mobile Nav - Placeholder */}
        <div className="lg:hidden fixed bottom-0 left-0 right-0 h-16 bg-[#09090b] border-t border-white/5 flex items-center justify-around px-4 z-50">
          <Link to="/" className={location.pathname === '/' ? 'text-cyan-400' : 'text-zinc-500'}><TrendingUp className="w-6 h-6" /></Link>
          <Link to="/library" className={location.pathname === '/library' ? 'text-cyan-400' : 'text-zinc-500'}><Search className="w-6 h-6" /></Link>
          <div className="w-12 h-12 bg-cyan-500 rounded-full -translate-y-4 flex items-center justify-center shadow-lg shadow-cyan-500/20 border-4 border-[#09090b]">
             <Gamepad2 className="text-black w-6 h-6" />
          </div>
          <Link to="/library?sort=rating" className="text-zinc-500"><Trophy className="w-6 h-6" /></Link>
          <Link to="/settings" className="text-zinc-500"><Settings className="w-6 h-6" /></Link>
        </div>
      </main>
    </div>
  );
}

export default function App() {
  return (
    <Router>
      <Layout>
        <Routes>
          <Route path="/" element={<Home />} />
          <Route path="/library" element={<AllGames />} />
          <Route path="/game/:id" element={<GameView />} />
          <Route path="*" element={<div className="flex items-center justify-center h-full text-zinc-500">View not implemented yet.</div>} />
        </Routes>
      </Layout>
    </Router>
  );
}
